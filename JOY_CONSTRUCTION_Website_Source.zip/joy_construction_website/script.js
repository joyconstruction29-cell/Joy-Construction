(() => {
  const $ = (selector) => document.querySelector(selector);
  const nav = $('.nav');
  const menuToggle = $('.menu-toggle');
  menuToggle.addEventListener('click', () => {
    const open = nav.classList.toggle('open');
    menuToggle.setAttribute('aria-expanded', String(open));
    menuToggle.textContent = open ? '×' : '☰';
  });
  nav.querySelectorAll('a').forEach(link => link.addEventListener('click', () => {
    nav.classList.remove('open');
    menuToggle.setAttribute('aria-expanded', 'false');
    menuToggle.textContent = '☰';
  }));

  const areaInput = $('#area');
  const packageInput = $('#package');
  const floorsInput = $('#floors');
  const totalOutput = $('#estimateTotal');
  const rateText = $('#rateText');
  const floorText = $('#floorText');
  const money = amount => new Intl.NumberFormat('en-IN', {style:'currency', currency:'INR', maximumFractionDigits:0}).format(amount);
  function updateEstimate() {
    const area = Math.max(0, Number(areaInput.value) || 0);
    const rate = Number(packageInput.value) || 0;
    const floors = Number(floorsInput.value) || 1;
    totalOutput.textContent = money(area * rate);
    rateText.textContent = `${money(rate)} × ${area.toLocaleString('en-IN')} sq.ft.`;
    floorText.textContent = `${floors === 1 ? '1 floor' : `${floors} floors`} selected`;
  }
  [areaInput, packageInput, floorsInput].forEach(input => input.addEventListener('input', updateEstimate));
  updateEstimate();

  document.querySelectorAll('[data-package]').forEach(button => button.addEventListener('click', () => {
    const name = button.dataset.package;
    packageInput.value = name === 'Normal Package' ? '1800' : name === 'Standard Package' ? '2000' : '2500';
    $('#formPackage').value = name === 'Normal Package' ? 'Normal · ₹1,800/sq.ft.' : name === 'Standard Package' ? 'Standard · ₹2,000/sq.ft.' : 'Luxury · ₹2,500/sq.ft.';
    updateEstimate();
  }));

  function openWhatsApp(message) {
    const url = `https://wa.me/918248289612?text=${encodeURIComponent(message)}`;
    window.open(url, '_blank', 'noopener,noreferrer');
  }
  $('#whatsappEstimate').addEventListener('click', () => {
    const area = Math.max(0, Number(areaInput.value) || 0);
    if (!area) { areaInput.focus(); areaInput.setCustomValidity('Please enter a built-up area greater than zero.'); areaInput.reportValidity(); areaInput.addEventListener('input', () => areaInput.setCustomValidity(''), {once:true}); return; }
    const rate = Number(packageInput.value);
    const packageName = rate === 1800 ? 'Normal Package' : rate === 2000 ? 'Standard Package' : 'Luxury Package';
    openWhatsApp(`Hello JOY CONSTRUCTION, I would like to discuss a construction estimate.\nBuilt-up area: ${area.toLocaleString('en-IN')} sq.ft.\nPackage: ${packageName}\nIndicative rate: ₹${rate.toLocaleString('en-IN')}/sq.ft.\nIndicative amount: ${money(area * rate)}\nPlease help me with a detailed quotation.`);
  });

  $('#quoteForm').addEventListener('submit', event => {
    event.preventDefault();
    const data = new FormData(event.currentTarget);
    const name = String(data.get('name') || '').trim();
    const phone = String(data.get('phone') || '').trim();
    if (!name || !phone) return;
    const message = [
      'Hello JOY CONSTRUCTION, I would like to request a quote.',
      `Name: ${name}`,
      `Phone: ${phone}`,
      `Service: ${data.get('service') || 'Not specified'}`,
      `Approx. built-up area: ${data.get('area') || 'Not specified'} sq.ft.`,
      `Package: ${data.get('package') || 'Not decided'}`,
      `Project location: ${data.get('location') || 'Not specified'}`,
      `Project details: ${data.get('message') || 'Not specified'}`
    ].join('\n');
    openWhatsApp(message);
  });

  $('#year').textContent = new Date().getFullYear();
  const revealObserver = ('IntersectionObserver' in window) ? new IntersectionObserver(entries => {
    entries.forEach(entry => { if (entry.isIntersecting) { entry.target.classList.add('visible'); revealObserver.unobserve(entry.target); } });
  }, {threshold:0.12}) : null;
  document.querySelectorAll('.service-card, .project-card, .package-card, .process-grid > div, .intro-copy, .intro-image').forEach(el => {
    el.classList.add('reveal');
    if (revealObserver) revealObserver.observe(el); else el.classList.add('visible');
  });
})();
